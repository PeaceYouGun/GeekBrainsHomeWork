package Lesson07.study;

public class Game {

    public static void main(String[] args) {
        new GameWindow();
    }
}
