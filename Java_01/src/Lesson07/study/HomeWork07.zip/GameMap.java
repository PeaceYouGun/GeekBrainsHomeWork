package Lesson07.study;

import javax.swing.*;
import java.awt.*;

public class GameMap extends JPanel {

    public static final int GAME_MODE_HVH = 0;
    public static final int GAME_MODE_HVA = 1;

    GameMap(){
        setBackground(Color.BLACK);
    }

    void start(int gameMode, int fieldSizeX, int fieldSizeY, int winLength) {
        System.out.println("gameMode: " + gameMode +
                "\nfieldSizeX: " + fieldSizeX +
                "\nfieldSizeY: " + fieldSizeY +
                "\nwinLength: " + winLength);
    }

}
