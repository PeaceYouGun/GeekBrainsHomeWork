package Lesson05.Animals;

import Lesson05.Animal;

public class Horse extends Animal {
    public Horse(String name) {
        super(3, name);
    }
}
