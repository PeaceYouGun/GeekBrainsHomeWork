package Lesson05.Animals;

import Lesson05.Animal;

public class Dog extends Animal {
    public Dog(String name) {
        super(2, name);
    }
}
