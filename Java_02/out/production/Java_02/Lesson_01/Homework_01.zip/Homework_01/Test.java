package Lesson_01.Homework_01;

public interface Test {
    String getType();

    int getValue();

    int getID();
}
